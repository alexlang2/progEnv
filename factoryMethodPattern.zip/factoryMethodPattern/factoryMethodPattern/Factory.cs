﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace factoryMethodPattern
{
    public abstract class Factory     //Abstract factory class
    {
       
         public abstract void drawHero(Form1 form, string hair, string weight, string mood);

    }
}
