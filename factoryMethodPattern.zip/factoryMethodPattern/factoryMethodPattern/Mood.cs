﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace factoryMethodPattern
{
    public class Mood
    {
        public bool isHappy(string mood)         //returns a pen object, returns true if string fills requirements.
        {
            if (mood == "happy")
                return true;
            return false;
        }
        
        public bool isNeutral(string mood)
        {
            if (mood == "neutral")
                return true;
            return false;
        }

        public bool isMad(string mood)
        {
            if (mood == "mad")
                return true;
            return false;
        }
    }
}
