﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace factoryMethodPattern
{
    class ConcreteFactory : Factory    //Concrete Factory class, inherits from factory.
    {

        string hair;
        string weight;
        string mood;
        Weight wt = new Weight();
        Mood md = new Mood();
        Hair hr = new Hair();

        public override void drawHero(Form1 f, string hair, string weight, string mood)
        {
            this.hair = hair;
            this.weight = weight;
            this.mood = mood;
            Graphics graphics = f.CreateGraphics();                          //Creates graphics on the main page
            Pen face = new Pen(Color.Blue, 4);

            f.CreateGraphics().Clear(Form1.ActiveForm.BackColor);
            graphics.DrawEllipse(wt.getWeight(weight), 680, 30, 80, 80);     //Draw Head
            graphics.DrawLine(wt.getWeight(weight), 720, 110, 720, 220);     //Draws the body
            graphics.DrawLine(wt.getWeight(weight), 640, 150, 800, 150);     //Draws Arms
            graphics.DrawLine(wt.getWeight(weight), 720, 218, 640, 275);     //Draws the Legs
            graphics.DrawLine(wt.getWeight(weight), 720, 218, 800, 275);

            graphics.DrawLine(face, 710, 50, 710, 70);
            graphics.DrawLine(face, 730, 50, 730, 70);                       //Draws eyes

            if (md.isHappy(mood))
            {
                graphics.DrawLine(face, 710, 80, 720, 95);                  //If happy, make happy
                graphics.DrawLine(face, 730, 80, 720, 95);
            }

            if (md.isNeutral(mood))
            {
                graphics.DrawLine(face, 710, 80, 730, 80);                 //If neutral, make neutral
            }

            if (md.isMad(mood))
            {
                graphics.DrawLine(face, 700, 40, 715, 50);                 //If mad, make mad
                graphics.DrawLine(face, 740, 40, 725, 50);
                graphics.DrawLine(face, 710, 95, 720, 80);
                graphics.DrawLine(face, 730, 95, 720, 80);
            }

            graphics.DrawLine(hr.getHair(hair), 700, 38, 700, 20);            //Creates the strands of hair
            graphics.DrawLine(hr.getHair(hair), 720, 30, 720, 12);
            graphics.DrawLine(hr.getHair(hair), 740, 38, 740, 20);

            graphics.Dispose();

        }

      
    }
}
