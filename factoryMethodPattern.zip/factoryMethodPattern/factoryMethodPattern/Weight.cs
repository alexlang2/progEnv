﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace factoryMethodPattern
{
    class Weight
    {
        Pen weightPen;


        public Pen getWeight(string weight)         //Returns a pen object, depends on user input
        {
            
            if(weight == "skinny")
            {
                weightPen = new Pen(Color.Blue, 2);
            }

            if(weight == "medium")
            {
                weightPen = new Pen(Color.Blue, 5);
            }
            
            if(weight == "large")
            {
                weightPen = new Pen(Color.Blue, 15);
            }

            return weightPen;
        }
    }
}
