﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace factoryMethodPattern
{
    public partial class Form1 : Form
    {


        public string hairColor = "brown";
        public string weight = "skinny";         //Default values.
        public string mood = "happy";
        ConcreteFactory CF = new ConcreteFactory();
        

        public Form1()
        {
            InitializeComponent();
        }

        

        private void createBtn_Click(object sender, EventArgs e)
        {
            CF.drawHero(this, hairColor, weight, mood);  //Creates the hero based on user input
        }

        //Radio buttons that send in available options.

        private void brownRadio_CheckedChanged(object sender, EventArgs e)
        {
            hairColor = "brown";
        }

        private void blackRadio_CheckedChanged(object sender, EventArgs e)
        {
            hairColor = "black";
        }

        private void blondeRadio_CheckedChanged(object sender, EventArgs e)
        {
            hairColor = "blonde";
        }

        private void skinnyRadio_CheckedChanged(object sender, EventArgs e)
        {
            weight = "skinny";
        }

        private void mediumRadio_CheckedChanged(object sender, EventArgs e)
        {
            weight = "medium";
        }

        private void largeRadio_CheckedChanged(object sender, EventArgs e)
        {
            weight = "large";
        }

        private void happyRadio_CheckedChanged(object sender, EventArgs e)
        {
            mood = "happy";
        }

        private void neutralRadio_CheckedChanged(object sender, EventArgs e)
        {
            mood = "neutral";
        }

        private void madRadio_CheckedChanged(object sender, EventArgs e)
        {
            mood = "mad";
        }
    }
}
