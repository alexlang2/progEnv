﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace factoryMethodPattern
{
    class Hair
    {
        Pen hairPen;

        public Pen getHair(string hair)
        {

            if (hair == "brown")                           //Determines color of hair, depending on user input.
            {
                hairPen = new Pen(Color.SaddleBrown, 3);
            }

            if (hair == "black")
            {
                hairPen = new Pen(Color.Black, 3);
            }

            if (hair == "blonde")
            {
                hairPen = new Pen(Color.Yellow, 3);
            }

            return hairPen;
        }
    }
}
