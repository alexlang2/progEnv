﻿namespace factoryMethodPattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.createBtn = new System.Windows.Forms.Button();
            this.brownRadio = new System.Windows.Forms.RadioButton();
            this.blackRadio = new System.Windows.Forms.RadioButton();
            this.blondeRadio = new System.Windows.Forms.RadioButton();
            this.skinnyRadio = new System.Windows.Forms.RadioButton();
            this.mediumRadio = new System.Windows.Forms.RadioButton();
            this.largeRadio = new System.Windows.Forms.RadioButton();
            this.happyRadio = new System.Windows.Forms.RadioButton();
            this.neutralRadio = new System.Windows.Forms.RadioButton();
            this.madRadio = new System.Windows.Forms.RadioButton();
            this.hairBox = new System.Windows.Forms.GroupBox();
            this.weightBox = new System.Windows.Forms.GroupBox();
            this.moodBox = new System.Windows.Forms.GroupBox();
            this.hairBox.SuspendLayout();
            this.weightBox.SuspendLayout();
            this.moodBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // createBtn
            // 
            this.createBtn.Location = new System.Drawing.Point(169, 301);
            this.createBtn.Name = "createBtn";
            this.createBtn.Size = new System.Drawing.Size(197, 23);
            this.createBtn.TabIndex = 0;
            this.createBtn.Text = "Create My Hero!";
            this.createBtn.UseVisualStyleBackColor = true;
            this.createBtn.Click += new System.EventHandler(this.createBtn_Click);
            // 
            // brownRadio
            // 
            this.brownRadio.AutoSize = true;
            this.brownRadio.Checked = true;
            this.brownRadio.Location = new System.Drawing.Point(9, 56);
            this.brownRadio.Name = "brownRadio";
            this.brownRadio.Size = new System.Drawing.Size(55, 17);
            this.brownRadio.TabIndex = 4;
            this.brownRadio.TabStop = true;
            this.brownRadio.Text = "Brown";
            this.brownRadio.UseVisualStyleBackColor = true;
            this.brownRadio.CheckedChanged += new System.EventHandler(this.brownRadio_CheckedChanged);
            // 
            // blackRadio
            // 
            this.blackRadio.AutoSize = true;
            this.blackRadio.Location = new System.Drawing.Point(12, 106);
            this.blackRadio.Name = "blackRadio";
            this.blackRadio.Size = new System.Drawing.Size(52, 17);
            this.blackRadio.TabIndex = 5;
            this.blackRadio.Text = "Black";
            this.blackRadio.UseVisualStyleBackColor = true;
            this.blackRadio.CheckedChanged += new System.EventHandler(this.blackRadio_CheckedChanged);
            // 
            // blondeRadio
            // 
            this.blondeRadio.AutoSize = true;
            this.blondeRadio.Location = new System.Drawing.Point(6, 151);
            this.blondeRadio.Name = "blondeRadio";
            this.blondeRadio.Size = new System.Drawing.Size(58, 17);
            this.blondeRadio.TabIndex = 6;
            this.blondeRadio.Text = "Blonde";
            this.blondeRadio.UseVisualStyleBackColor = true;
            this.blondeRadio.CheckedChanged += new System.EventHandler(this.blondeRadio_CheckedChanged);
            // 
            // skinnyRadio
            // 
            this.skinnyRadio.AutoSize = true;
            this.skinnyRadio.Checked = true;
            this.skinnyRadio.Location = new System.Drawing.Point(6, 56);
            this.skinnyRadio.Name = "skinnyRadio";
            this.skinnyRadio.Size = new System.Drawing.Size(57, 17);
            this.skinnyRadio.TabIndex = 7;
            this.skinnyRadio.TabStop = true;
            this.skinnyRadio.Text = "Skinny";
            this.skinnyRadio.UseVisualStyleBackColor = true;
            this.skinnyRadio.CheckedChanged += new System.EventHandler(this.skinnyRadio_CheckedChanged);
            // 
            // mediumRadio
            // 
            this.mediumRadio.AutoSize = true;
            this.mediumRadio.Location = new System.Drawing.Point(6, 106);
            this.mediumRadio.Name = "mediumRadio";
            this.mediumRadio.Size = new System.Drawing.Size(62, 17);
            this.mediumRadio.TabIndex = 8;
            this.mediumRadio.Text = "Medium";
            this.mediumRadio.UseVisualStyleBackColor = true;
            this.mediumRadio.CheckedChanged += new System.EventHandler(this.mediumRadio_CheckedChanged);
            // 
            // largeRadio
            // 
            this.largeRadio.AutoSize = true;
            this.largeRadio.Location = new System.Drawing.Point(6, 151);
            this.largeRadio.Name = "largeRadio";
            this.largeRadio.Size = new System.Drawing.Size(52, 17);
            this.largeRadio.TabIndex = 9;
            this.largeRadio.Text = "Large";
            this.largeRadio.UseVisualStyleBackColor = true;
            this.largeRadio.CheckedChanged += new System.EventHandler(this.largeRadio_CheckedChanged);
            // 
            // happyRadio
            // 
            this.happyRadio.AutoSize = true;
            this.happyRadio.Checked = true;
            this.happyRadio.Location = new System.Drawing.Point(6, 56);
            this.happyRadio.Name = "happyRadio";
            this.happyRadio.Size = new System.Drawing.Size(56, 17);
            this.happyRadio.TabIndex = 10;
            this.happyRadio.TabStop = true;
            this.happyRadio.Text = "Happy";
            this.happyRadio.UseVisualStyleBackColor = true;
            this.happyRadio.CheckedChanged += new System.EventHandler(this.happyRadio_CheckedChanged);
            // 
            // neutralRadio
            // 
            this.neutralRadio.AutoSize = true;
            this.neutralRadio.Location = new System.Drawing.Point(6, 106);
            this.neutralRadio.Name = "neutralRadio";
            this.neutralRadio.Size = new System.Drawing.Size(59, 17);
            this.neutralRadio.TabIndex = 11;
            this.neutralRadio.Text = "Neutral";
            this.neutralRadio.UseVisualStyleBackColor = true;
            this.neutralRadio.CheckedChanged += new System.EventHandler(this.neutralRadio_CheckedChanged);
            // 
            // madRadio
            // 
            this.madRadio.AutoSize = true;
            this.madRadio.Location = new System.Drawing.Point(6, 151);
            this.madRadio.Name = "madRadio";
            this.madRadio.Size = new System.Drawing.Size(46, 17);
            this.madRadio.TabIndex = 12;
            this.madRadio.Text = "Mad";
            this.madRadio.UseVisualStyleBackColor = true;
            this.madRadio.CheckedChanged += new System.EventHandler(this.madRadio_CheckedChanged);
            // 
            // hairBox
            // 
            this.hairBox.Controls.Add(this.brownRadio);
            this.hairBox.Controls.Add(this.blackRadio);
            this.hairBox.Controls.Add(this.blondeRadio);
            this.hairBox.Location = new System.Drawing.Point(27, 45);
            this.hairBox.Name = "hairBox";
            this.hairBox.Size = new System.Drawing.Size(123, 229);
            this.hairBox.TabIndex = 13;
            this.hairBox.TabStop = false;
            this.hairBox.Text = "Hair Color:";
            // 
            // weightBox
            // 
            this.weightBox.Controls.Add(this.skinnyRadio);
            this.weightBox.Controls.Add(this.mediumRadio);
            this.weightBox.Controls.Add(this.largeRadio);
            this.weightBox.Location = new System.Drawing.Point(211, 45);
            this.weightBox.Name = "weightBox";
            this.weightBox.Size = new System.Drawing.Size(122, 229);
            this.weightBox.TabIndex = 14;
            this.weightBox.TabStop = false;
            this.weightBox.Text = "Weight:";
            // 
            // moodBox
            // 
            this.moodBox.Controls.Add(this.happyRadio);
            this.moodBox.Controls.Add(this.neutralRadio);
            this.moodBox.Controls.Add(this.madRadio);
            this.moodBox.Location = new System.Drawing.Point(402, 45);
            this.moodBox.Name = "moodBox";
            this.moodBox.Size = new System.Drawing.Size(123, 229);
            this.moodBox.TabIndex = 15;
            this.moodBox.TabStop = false;
            this.moodBox.Text = "Mood:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(913, 346);
            this.Controls.Add(this.moodBox);
            this.Controls.Add(this.weightBox);
            this.Controls.Add(this.hairBox);
            this.Controls.Add(this.createBtn);
            this.Name = "Form1";
            this.Text = "Hero Creator";
            this.hairBox.ResumeLayout(false);
            this.hairBox.PerformLayout();
            this.weightBox.ResumeLayout(false);
            this.weightBox.PerformLayout();
            this.moodBox.ResumeLayout(false);
            this.moodBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button createBtn;
        private System.Windows.Forms.RadioButton brownRadio;
        private System.Windows.Forms.RadioButton blackRadio;
        private System.Windows.Forms.RadioButton blondeRadio;
        private System.Windows.Forms.RadioButton skinnyRadio;
        private System.Windows.Forms.RadioButton mediumRadio;
        private System.Windows.Forms.RadioButton largeRadio;
        private System.Windows.Forms.RadioButton happyRadio;
        private System.Windows.Forms.RadioButton neutralRadio;
        private System.Windows.Forms.RadioButton madRadio;
        private System.Windows.Forms.GroupBox hairBox;
        private System.Windows.Forms.GroupBox weightBox;
        private System.Windows.Forms.GroupBox moodBox;
    }
}

