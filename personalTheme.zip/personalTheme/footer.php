<div id="footer">
    <p>Powered by Wordpress!</p>
</div>
</div>
</body>
</html>

