<html>
<head>
    <title>ONU Lang</title>
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
</head>
<body>
    <div id="header">
        <h1>ONU Lang</h1>
        <p>Don't let your dreams be dreams!</p>
    </div>