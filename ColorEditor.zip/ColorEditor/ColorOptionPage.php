<div class="wrap">
    <p>My Plugin Database Table Prefix</p>
    <input type="text" value="ce_">
</div>