<?php
include_once('Color.php');
Product::delete("ce_ColorValues", $_POST['id']);